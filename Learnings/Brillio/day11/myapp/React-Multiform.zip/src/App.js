
// import A from './Components/A';
// import {useBreakPoint } from './Components/CustomHook3'
import './App.css'
import SignUp from './Components/HomeAssignment/SignUp';
// import Player from './ClassAssignment/PlayersList'
import App5 from './Components/App5_v2'
// function App() {
//   const {breakpoint,width }  = useBreakPoint();
//   return (
//   <div>  

//     <h1>APP COMPONENT</h1>
    
//     {/* <span style={{ height:'2px' , display:'inline-block', backgroundColor:'black' , width :'1000px',marginTop:'40px'}}/> */}
//     <p>WIDTH: {width} and Breakpoint :{breakpoint}</p>
//   </div>
//   )
// }

// export default App;


// function App(){
//   // return <Player/>
//   return <App5/>
  
// }

function App(){
 return <SignUp/>
}

export default App;
