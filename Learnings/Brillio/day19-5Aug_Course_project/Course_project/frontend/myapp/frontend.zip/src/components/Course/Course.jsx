import React, { useState } from "react";
import "./Course.scss";
import { Link } from "react-router-dom";
import { deleteCourse } from "../../services";
import EditCourse from "../EditCourse/edit-course";
import { Modal, ModalHeader, ModalBody } from "reactstrap";
const Course = ({ course }) => {
  const { courseName, courseId, courseDuration, courseFee } = course;
  const [modal, setModal] = useState(false);
  const toggle = () => {
    setModal(!modal);
  };
  const toggleEditCourseModal = () => {
    setModal(!modal);
    toggle();
  };
  const handleDelete = () => {
    if (!window.confirm("Are you sure you want to delete")) return;
    deleteCourse(courseId)
      .then((res) => console.log(res))
      .catch((err) => console.log(err));
  };
  return (
    <>
     <div className="course-row">
          <div className="course-details">
            <div className="course-item">{courseId}</div>
            <div className="course-title">{courseName}</div>
            <div className="course-item">{courseDuration}</div>
            <div className="course-item">{courseFee}</div>
          </div>
          <div className="button-group">
            <button className='btn' type="button">Edit</button>
            <button className='btn' type="button">VIEW</button>
            <button className='btn' type="button">DELETE</button>
          </div>
    </div>
     <Modal isOpen={modal} toggle={toggleEditCourseModal}>
     <ModalHeader> EDIT PLAYER</ModalHeader>
     <ModalBody>
       <EditCourse data = {course}/>
     </ModalBody>
   </Modal>
    </>
   
  );
};

export default Course;
