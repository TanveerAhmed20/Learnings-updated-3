export default function ViewPlayers() {
  return (
  <h1>View Player</h1>
  );
}
