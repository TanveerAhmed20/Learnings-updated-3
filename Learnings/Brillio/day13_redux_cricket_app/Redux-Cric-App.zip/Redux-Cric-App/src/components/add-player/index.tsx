import React from "react";

const AddPlayer = () =>{
  return (
    <h1> Add Player </h1>
  );
}


export default AddPlayer;
